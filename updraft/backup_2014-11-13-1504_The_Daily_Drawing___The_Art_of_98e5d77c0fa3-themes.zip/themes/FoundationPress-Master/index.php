<?php get_header(); ?>


	<div class="small-12 large-9 columns" role="main">
	<?php if ( have_posts() ) : ?>
	
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', get_post_format() ); ?>
			
		<?php endwhile; ?>
		
		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		
	<?php endif;?>
	<script>
  			var jsPostCount = <?php echo json_encode($postCount); ?>;
	</script>
		<nav id="post-nav">
			<div class="post-previous"><?php next_posts_link( __( 'Older posts', 'FoundationPress' ) ); ?></div>
			<div class="post-next"><?php previous_posts_link( __( 'Newer posts', 'FoundationPress' ) ); ?></div>
		</nav>

	</div>
	<?php get_sidebar(); ?>
		
<?php get_footer(); ?>
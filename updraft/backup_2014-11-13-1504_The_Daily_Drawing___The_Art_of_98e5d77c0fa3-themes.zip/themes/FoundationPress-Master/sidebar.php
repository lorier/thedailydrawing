<aside id="sidebar" class="small-12 medium-6 large-3 columns">
	<?php dynamic_sidebar("Sidebar"); ?>
</aside>
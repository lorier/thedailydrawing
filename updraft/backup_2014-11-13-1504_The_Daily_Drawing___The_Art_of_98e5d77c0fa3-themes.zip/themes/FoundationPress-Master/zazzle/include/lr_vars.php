<?php 

/***************************************************/
/*    TDD Code   */
/*  Setting up code to fix small bugs  */
/****************************************************/	

//Find page slug to prepend to the pagination url in zstore.php
// $pageSlug = global $post; echo $post->post_name;;
// echo $pageSlug;
?>
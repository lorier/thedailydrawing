<?php
/*
Template Name: Store
*/
get_header(); ?>

	<div class="small-12 large-12 columns" role="main">
	
	<?php /* Start loop */ ?>
	<?php while (have_posts()) : the_post(); ?>
		<article <?php post_class() ?> id="post-<?php the_ID(); ?>">
			<header>
				<h2 class="entry-title"><?php the_title(); ?></h2>
			</header>
			
			<div class="entry-content page-store">
				<?php the_content(); ?>
				<?php
			//get the slug to add to pagination urls
			$post = get_post(isset($post_id)); 
			$pageSlug = $post->post_name;
			
			// configure Zazzle Store Builder display
			
			 include "zazzle/include/zstore.php";
			 
			?>
			</div>
			
		</article>
	<?php endwhile; // End the loop ?>

	</div>
		
<?php get_footer(); ?>
<?php
/**
 * The default template for displaying content. Used for both single and index/archive/search.
 *
 * @subpackage FoundationPress
 * @since FoundationPress 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<header>
		<h2 class="day-number entry-title"><?php the_title(); ?></h2><h2 class="date-of-drawing"><?php FoundationPress_entry_meta(); ?></h2>
	</header>
	<div class="entry-content">
		<?php the_content(__('Continue reading...', 'FoundationPress')); ?>
	</div>
	<footer>

		<div><a href="<?php comments_link(); ?>" class="comments-bubble">Make a Comment</a></div>
		<div><a href="<?php comments_link(); ?>"><?php comments_number( '', '<span class="comments">Comments: </span><span class="number">1</span>', '<span class="comments">Comments: </span><span class="number">%</span>' ); ?></a></div>
		<span class="vcard author post-author" style="display: none;"><span class="fn"><?php the_author(); ?></span></span>
		<?php /**ditching tags for categories*/?>
		<div class="categories-group"><?php
			$categories = get_the_category();
			$separator = ' ';
			$output = '';
			if($categories){
				foreach($categories as $category) {
						if ($category->cat_name == 'Uncategorized'){} else {
							$output .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $category->name ) ) . '">'.$category->cat_name.'</a>'.$separator;
						}
					}
				if ($output == ''){} 
					else 
					{
						/**need to add code to match pluralization of Categories to number of results*/
						echo ('<span class="categories">Categories:&#160;&#160;</span>');
						echo trim($output, $separator);
				}
			}
		?></div>

	<div class="clear"></div>
	</footer>
</article>
<div class="post-connector"></div>

<?php
global $postCount;
++$postCount;
?>

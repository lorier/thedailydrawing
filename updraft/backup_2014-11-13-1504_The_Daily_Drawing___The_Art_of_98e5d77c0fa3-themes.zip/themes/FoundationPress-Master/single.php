<?php get_header(); ?>

	<div class="small-12 large-9 columns" role="main">
	
	<?php while (have_posts()) : the_post(); ?>
		<article <?php post_class() ?> id="post-<?php the_ID(); ?>">

			<header>
				<h2 class="day-number"><?php the_title(); ?></h2><h2 class="date-of-drawing"><?php FoundationPress_entry_meta(); ?></span></h2>
			</header>
			<div class="entry-content">
				<?php the_content(); ?>
			</div>
			<footer>

			<div><a href="<?php comments_link(); ?>" class="comments-bubble">Make a Comment</a></div>
			<div><a href="<?php comments_link(); ?>"><?php comments_number( '', '<span class="comments">Comments: </span><span class="number">1</span>', '<span class="comments">Comments: </span><span class="number">%</span>' ); ?></a></div>
	
			<?php /* $tag = get_the_tags(); if (!$tag) { } else { ?><span class="tags-list"><?php the_tags('<span class="tags">Tags: </span>',', ',''); ?></span><?php } */ ?>
			<?php /**ditching tags for categories*/?>
				<div class="categories-group"><?php
					$categories = get_the_category();
					$separator = ' ';
					$output = '';
					if($categories){
						foreach($categories as $category) {
								if ($category->cat_name == 'Uncategorized'){} else {
									$output .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $category->name ) ) . '">'.$category->cat_name.'</a>'.$separator;
								}
							}
						if ($output == ''){} 
							else 
							{
								/**need to add code to match pluralization of Categories to number of results*/
								echo ('<span class="categories">Categories:&#160;&#160;</span>');
								echo trim($output, $separator);
						}
					}
				?></div>
				<?php wp_link_pages(array('before' => '<nav id="page-nav"><p>' . __('Pages:', 'FoundationPress'), 'after' => '</p></nav>' )); ?>
				<?php $tag = get_the_tags(); if (!$tag) { } else { ?><span class="tags-list"><?php the_tags('<span class="tags-title">Tags: </span>',', ',''); ?></span><?php } ?>

			<div class="clear"></div>
			</footer>
			<?php comments_template(); ?>
		</article>
	<?php endwhile;?>

	</div>
	<?php get_sidebar(); ?>
		
<?php get_footer(); ?>